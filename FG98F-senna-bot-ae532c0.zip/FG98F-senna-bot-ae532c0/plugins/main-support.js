 
let handler = async (m, { conn }) => {

m.reply(`
≡  *${botName}ᴮᴼᵀ ┃ SUPPORT*

◈ ━━━━━━━━━━━━━━━━━━━━ ◈
▢ Grupo *1*
${bgp}

▢ Grupo *2*
${bgp2}

▢ Grupo *NSFW* 🔞
${bgp3}

▢ 𝐌𝐘 - 𝐌𝐚𝐲𝐥𝐮𝐱 | ᴮᴼᵀ⚡
https://chat.whatsapp.com/CTILZXSriIE3M40anVyPT4

▢ 📲💻ANDROID WORLD🎬🎮
https://chat.whatsapp.com/Ly4I2LObSvW8VgOnJjofgA

◈ ━━━━━━━━━━━━━━━━━━━━ ◈
▢ Todos los Grupos
 https://instabio.cc/fg98ff

▢ *Telegram*
• https://t.me/fgawgp
 ▢ *PayPal*
• https://paypal.me/fg98f
▢ *YouTube*
• https://www.youtube.com/fg98f`)

}
handler.help = ['support']
handler.tags = ['main']
handler.command = ['grupos', 'groups', 'support'] 

export default handler
